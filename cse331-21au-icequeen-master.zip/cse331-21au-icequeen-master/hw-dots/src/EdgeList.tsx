/*
 * Copyright (C) 2021 Kevin Zatloukal.  All rights reserved.  Permission is
 * hereby granted to students registered for University of Washington
 * CSE 331 for use solely during Spring Quarter 2021 for purposes of
 * the course.  No other use, copying, distribution, or modification
 * is permitted without prior written consent. Copyrights for
 * third-party components of this work must be honored.  Instructors
 * interested in reusing these course materials should contact the
 * author.
 */

import React, {Component} from 'react';

interface EdgeListProps {
    onChange(edges: any): void;  // called when a new edge list is ready
                                 // once you decide how you want to communicate the edges to the App, you should
                                 // change the type of edges so it isn't `any`
}

interface EdgeListState {
    content: string,             // control content when user changes the webpage state based on input
}

/**
 * A text field that allows the user to enter the list of edges.
 * Also contains the buttons that the user will use to interact with the app.
 */
class EdgeList extends Component<EdgeListProps, EdgeListState> {
    constructor(props: EdgeListProps) {
        super(props);
        this.state = {
            content: ""     // content is empty
        };
    }

    /* Updates webpage when text-box is empty (cleared) */
    onClear = () => {
        this.setState({content: ""});
        this.props.onChange([]);
    }

    /* Updates webpage when user input changes */
    onInputChange = (event: React.ChangeEvent<HTMLTextAreaElement>) => {
        const content: string = event.target.value;
        this.setState({content: content});
    };


    /* Updates webpage to draw the line & edges */
    onDraw = () => {

        // Variables
        const content: string = this.state.content,                     // Initialize state content
            list: string[] = content.split("\n");               // Initialize data list

        let edge_list: [number, number, number, number, string][] = []; // Initialize edge list

        // Traverse all rows
        list.forEach((row: string) => {

            // Analyze rows - Print out
            console.log("Row:", row);

            // Parse row data
            let items: string[] = row.split(" ");

            // Check Item Length
            let itemLength = 3;
            if (items.length < itemLength) {
                alert("Error! Unable to read line input \n[Must be in the form of: x1,y1 x2,y2 color]");
                return;
            }

            // Start & End Point Variables
            let start_pt: string[] = items[0].split(","),
                end_pt: string[] = items[1].split(",");

            // Check Start & End Points Length
            let maxPtLength = 2;
            if (start_pt.length < maxPtLength || end_pt.length < maxPtLength) {
                alert("Error! Unable to read line input \n[Must be in the form of: x1,y1 x2,y2 color]");
                return;
            }

            // Set coordinates to variables form the data parse
            let x1: number = parseInt(start_pt[0]);
            let y1: number = parseInt(start_pt[1]);
            let x2: number = parseInt(end_pt[0]);
            let y2: number = parseInt(end_pt[1]);
            let color: string = items[2];

            // Push data to edge_list
            edge_list.push([x1, y1, x2, y2, color]);
        });

        // Reference from ...
        this.props.onChange(edge_list);
    }


    render() {
        return (
            <div id="edge-list">
                Edges <br/>
                <textarea
                    rows={5}
                    cols={30}
                    onChange={this.onInputChange}   // MODIFIED onChange, value and buttons
                    value={this.state.content}    // "I'm still stuck!!!"
                /> <br/>
                <button onClick={this.onDraw}>Draw</button>
                <button onClick={this.onClear}>Clear</button>
            </div>
        );
    }
}

export default EdgeList;
