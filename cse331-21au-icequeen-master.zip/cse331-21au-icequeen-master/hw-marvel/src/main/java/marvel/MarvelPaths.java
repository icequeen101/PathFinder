package marvel;

import graph.UpdatedGraph;
import graph.EdgeLabeled;

import java.io.IOException;
import java.util.*;

public class MarvelPaths {

    public static void main(String[] args)
            throws IOException {

        // Initialize scanner and graph objects 
        Scanner user_input = new Scanner(System.in);
        UpdatedGraph<String, String> newMarvelGraph = newGraph("marvel.csv");

        // Initialize boolean variables 
        boolean graphContainsSource,
                graphContainsDest;

        // Initialize String variables 
        String answer = "yes",
                sourceNode_character,
                destNode_character;


        // While the program is running 
        while (answer.equals("yes")) {

            // Get Starting Node
            marvelMapStartText();
            sourceNode_character = user_input.nextLine();

            // Get the Ending Node
            marvelMapEndText();
            destNode_character = user_input.nextLine();
            System.out.println();

            // Update boolean variables
            graphContainsSource = newMarvelGraph.containsNode(sourceNode_character);
            graphContainsDest = newMarvelGraph.containsNode(destNode_character);

            // Check Cases
            // Case 1: No source or dest nodes found
            if (!graphContainsSource && !graphContainsDest)
                System.out.println("Marvel Characters Not Found");

            // Case 2: No source
            else if (!graphContainsSource)
                System.out.println("1st Marvel Character Not Found");

            // Case 2: No dest
            else if (!graphContainsDest)
                System.out.println("2nd Marvel Character Not Found");

            // Find Path
            else {

                // Initialize ArrayList
                ArrayList<EdgeLabeled<String, String>> path = getShortestPath(sourceNode_character, destNode_character, newMarvelGraph);

                // Initialize String Variables
                String tmp = sourceNode_character,
                        result = "Finding Path From " + sourceNode_character + " To " + destNode_character + ":";

                // Case Check Loops
                // Case 1: Self-Loop
                if (sourceNode_character.equals(destNode_character))
                    result += "";

                // Case 2: Empty Path
                else if (path.isEmpty())
                    result += "\n" + "No Path Found...";

                // Print Path
                else {

                    // TRAVERSE: for every edge in the path
                    for (EdgeLabeled<String, String> edge : path) {
                        result += "\n" + tmp + " To " + edge.getDest() + " Via " + edge.getLabel() + "\n";
                        tmp = edge.getDest();
                    }
                }
                System.out.println(result);
            }
            // RE-RUN Program
            System.out.println("Find Shortest Path Between Two Marvel Characters Again?");
            System.out.println("Enter 'yes' or 'no': ");
            answer = user_input.nextLine();
        }
        System.out.println("EXITING...");
    }

    public static void marvelMapStartText() {
        System.out.println("Enter starting marvel character. ");
        System.out.println("Please type in capital letters and use dashes (-) for spaces between names.");
        System.out.println("If they have different names, type them in alphabetical order.");
        System.out.println("Separate the names with a slash (/). Example: 3-D-MAN/CHARLES-CHAN");
        System.out.print("Input here: ");
    }

    public static void marvelMapEndText() {
        System.out.println("Enter starting marvel character. ");
        System.out.println("Please type in capital letters and use dashes (-) for spaces between names.");
        System.out.println("If they have different names, type them in alphabetical order.");
        System.out.println("Separate the names with a slash (/). Example: 3-D-MAN/CHARLES-CHAN");
        System.out.print("Input here: ");
    }

    public static UpdatedGraph<String, String> newGraph(String filename)
            throws IOException {
        // Initialize Objects 
        ArrayList<String> characterList = new ArrayList<>();                                                // ArrayList
        UpdatedGraph<String, String> marvelGraph = new UpdatedGraph<>();                                    // Graph 
        HashMap<String, ArrayList<String>> marvelHashMap = MarvelParser.parseData(filename, characterList); // HashMap 

        //boolean startEqualsEnd = sourceNode.equals(destNode); 

        // TRAVERSE for characters in the character list 
        for (String character : characterList)
            marvelGraph.addNode(character); // add the characters nodes into the marvelGraph 

        // TRAVERSE for comic book in the marvel HashMap - use keySet()
        for (String comicBook : marvelHashMap.keySet())

            // TRAVERSE for start nodes in the comic book - marvel HashMap 
            for (String sourceNode : marvelHashMap.get(comicBook))

                // TRAVERSE for end nodes in the comic book - marvel HashMap 
                for (String destNode : marvelHashMap.get(comicBook))

                    // CONDITION: Check if start and end node equals 
                    if (!sourceNode.equals(destNode))
                        marvelGraph.addEdge(sourceNode, destNode, comicBook);     // Add edges 


        return marvelGraph;
    }

    public static ArrayList<EdgeLabeled<String, String>> getShortestPath(String sourceNode,
                                                                         String destNode,
                                                                         UpdatedGraph<String, String> graph) {

        // Initialize Objects 
        HashMap<String, ArrayList<EdgeLabeled<String, String>>> marvelPaths = new HashMap<>();  // HashMap
        Queue<String> nodesToVisit_List = new LinkedList<>();                                   // Queue

        // Initialize Strings & Other Variables 
        String nextNode, endNode;
        boolean startEqualsEnd, mapContains;

        // Starting node - got to nodesToVisit_List 
        nodesToVisit_List.add(sourceNode);

        // Check this command 
        marvelPaths.put(sourceNode, new ArrayList<>());

        // TRAVERSE through the nodes to be visited list 
        while (!nodesToVisit_List.isEmpty()) {

            // Once visited, remove node
            nextNode = nodesToVisit_List.remove();

            // Update boolean 
            startEqualsEnd = nextNode.equals(destNode);

            // Check if start node equals the end node 
            if (startEqualsEnd)
                return (marvelPaths.get(destNode));

            // Use ArrayList to creat the edges list 
            ArrayList<EdgeLabeled<String, String>> edgesList = new ArrayList<>(graph.getEdges(nextNode));

            // Use Collections to sort through all the data  
            Collections.sort(edgesList, Comparator.comparing(edge -> edge.getDest() + edge.getLabel()));

            // TRAVERSE: edges in edges list 
            for (EdgeLabeled<String, String> edge : edgesList) {

                // Get the destiantion node
                endNode = edge.getDest();

                // Check if map contains the endNode
                mapContains = marvelPaths.containsKey(endNode);

                // TRAVERSE: ^^^
                if (!mapContains) {

                    // Initialize the ArrayList fo the path list
                    ArrayList<EdgeLabeled<String, String>> pathList = new ArrayList<>(marvelPaths.get(nextNode));

                    // Update path list
                    pathList.add(edge);                 // Add edge
                    marvelPaths.put(endNode, pathList); // Use put()
                    nodesToVisit_List.add(endNode);     // Add node
                }
            }
        }
        return null;
    }
}