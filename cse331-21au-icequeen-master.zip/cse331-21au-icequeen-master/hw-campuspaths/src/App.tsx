/*
 * Copyright (C) 2021 Kevin Zatloukal.  All rights reserved.  Permission is
 * hereby granted to students registered for University of Washington
 * CSE 331 for use solely during Spring Quarter 2021 for purposes of
 * the course.  No other use, copying, distribution, or modification
 * is permitted without prior written consent. Copyrights for
 * third-party components of this work must be honored.  Instructors
 * interested in reusing these course materials should contact the
 * author.
 */

import React, {Component} from 'react';

// Import additional libraries
import "./App.css";
import MapView from './MapView';

/*
    MODIFIED: A lot of this file
    Reference: A lot from the HW9 Video & W3 School
 */

interface AppState {
    buildings: string[] | [];   // list of the campus buildings
    start: string | "";         // the beginning of the path to display
    end: string | "";           // the end of the path to display
    path: any | [],             // the path to display
    requestResult: string;      // the path to display
}


class App extends Component<{}, AppState> {
    start: string = "";
    end: string = "";

    constructor(props: {}) {
        super(props);

        // Don't need to store the sting result of a request in state,
        // be using it to display the string on the page - Comment out requestResult?

        this.state = {
            buildings: [],
            start: "",
            end: "",
            path: [],
            requestResult: "DO STUFF!"
        };
    }

    /*
        Function Name: componentDidMount()
        Reference: W3 School
        Description: The componentDidMount() method allows us to execute the React code when the component is already
        placed in the DOM (Document Object Model). This method is called during the Mounting phase of the React
        Life-cycle i.e after the component is rendered.

        Usage: We get the building names.
     */

    async componentDidMount() {
        await this.getBuildingNames();
    }

    /*
        Function Name: getBuildingNames()
        Reference: W3 School
        Description: Retrieve the names of all the campus buildings
     */

    async getBuildingNames() {
        try {
            let url = await fetch('http://localhost:4567/getBuildingNames');
            // let responsePromise = fetch(url);
            let response = await url.json();

            // if (!response.ok){
            //     alert("ERROR --> Not OK " + response.status);
            //     return;
            // }

            this.setState({
                buildings: response,
                start: response[0],
                end: response[0],
            });
        } catch(error) {
            console.error(error);
        }
    }

    /*
        Function Name: updateStartBuilding()
        Description: Update the map paths when the starting building is changed
     */

    async updateStartBuilding(event: React.FormEvent) {
        let newBuilding = ((event.target) as any).value;    // Get new data
        await this.setState({start: newBuilding});     // Set state
        await this.findPath();                              // Find new path
    }

    /*
        Function Name: updateEndBuilding()
        Description: Update the map paths when the ending building is changed
     */
    async updateEndBuilding(event: React.FormEvent) {
        let newBuilding = ((event.target) as any).value;    // Get new data
        await this.setState({end: newBuilding});       // Set state
        await this.findPath();                              // Find new path
    }

    /*  Gets the path from the starting building to the ending building so that it can be displayed */
    async findPath() {
        try {

            /* Referenced HW9 Video & Code for URL
               Access the state and use input values to modify the path we are getting
             */

            let url = await fetch('http://localhost:4567/findPath?start='
                + '${this.state.start}'
                + '&end=${this.state.end}');

            // let responsePromise = fetch(url);

            let response = await url.json();

            // if (!response.ok){
            //      alert("ERROR --> Not OK " + response.status);
            //     return;
            // }

            /*
                let parsedObject = await response.json();

                if (parsedObject == null){
                    console.log("No Path found");

                    this.setState({
                    requestResult: No path found.
                })

                Note: Parse data? Ask TA
             */

            this.setState({path: response.path})


        } catch(error) {
            // alert("Error in contacting the server.")
            console.error("findPath() : ERROR :", error);
        }
    }

    /*
       Function Name: resetMap()
       Description: Reset Map - Clear all selections
    */
    async resetMap(event: React.FormEvent ) {
        await this.setState({start: this.state.buildings[0] + ""}); // Reset starting building
        await this.setState({end: this.state.buildings[0] + ""});   // Reset ending building
        await this.findPath();                                           // Reset paths
    }

    render() {

        // Change which callbacks is assigned to the start & end buttons to try out the different demos

        return (
            <div>
                <div className="App">

                    <label>Starting Building</label>
                    <select value={this.state.start} onChange={(e) => this.updateStartBuilding(e)}>
                        {this.state.buildings?.map((item: string) => {
                            return (<option key={item} value={item}>{item}</option>);
                        })}
                    </select>

                    <label>Ending Building</label>
                    <select value={this.state.end} onChange={(e) => this.updateEndBuilding(e)}>
                        {this.state.buildings?.map((item: string) => {
                            return (<option key={item} value={item}>{item}</option>);
                        })}
                    </select>

                    <button onClick={(e) => this.resetMap(e)}>Reset</button>
                </div>
                <MapView path={this.state.path} />
            </div>
        );
    }

}

export default App;