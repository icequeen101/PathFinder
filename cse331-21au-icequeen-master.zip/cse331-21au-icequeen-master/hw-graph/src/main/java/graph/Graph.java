package graph;

// Import the libraries
import java.util.Set;
import java.util.HashSet;
import java.util.HashMap;
import java.util.Collections;

/**
 * Name: Graph - Class
 * Description: Class that represents a directed and mutable graph.
 * It includes a collection of nodes and edges, where each edge contains a dest. node and the edgB label.
 *
 * @param <A> The type of nodes in the Graph
 * @param <B> The type of edges in the Graph
 */


public class Graph<A,B> {

    public static final boolean GRAPH_DEBUG = false;                    // GRAPH_DEBUG flag for checkRep()
    public static final int GRAPH_NULL = 0;                             // Graph Null Macro-value

    private final HashMap<A, HashSet<EdgeLabeled<A, B>>> new_graph;     // Graph: Contain nodes & their connecting edges w/ labels.

  /* Abstraction Function (AF):
        AF(this) = Graph new_graph
            new_graph = {} -> empty graph
            new_graph = {node_1 = [],...} -> node_1 has no outgoing edges
            new_graph = {node_1 = [(node_2, edge_12), (node_3, edge_13),...], node_2 = [...], node_3 = [...],...}
                        -> edge_12's & edge_13's dest. nodes are node_2 & node_3 outgoing from node_1

        IGNORE THIS Note: I used the dormat [[node1, edge_12]] in the code and I am too lazy to fix it.
        Edit: I fixed it.

     Representation Invariant (RI):
        Graph is not equal to null, each edge/node is not equal to null, & graph must have the node & edgB labels
        included

     */

    /**
     * Name: Graph()
     * Description: Creates an empty directed labeled graph.
     *
     * @spec.effects Creates an empty directed labeled graph
     */
    public Graph() {
        new_graph= new HashMap<>();
        // checkRep needed - Check this -- CHECKED
        checkRep();
    }
    
    /********************************************* NODES ****************************************************/ 

    /**
     * Name: addNode()
     * Description: Add new node to graph, if node is not already in graph
     *
     * @param node - node to-be-added to graph
     * @return true - if node successfully added to graph; otherwise, return false
     * @spec.requires node != null
     * @spec.modifies this
     * @spec.effects node added to graph, if node not already present in graph
     */
    public boolean addNode(A node) {
        checkRep();  // checkRep needed - Check this -- CHECKED

        if (node == null)
            throw new IllegalArgumentException("Null Node");

        if (containsNode(node))
            return false;

        else {      // Check Java dic for add() command?
            new_graph.put(node, new HashSet<>());   // Use put()
            return true;
        }
    }

    
    /**
     * Name: containsNode()
     * Description: Check if node is in graph.
     *
     * @param node - check if node is in graph
     * @return true - if the node is in graph; otherwise, return false
     * @spec.requires node != null
     */
    public boolean containsNode(A node) {
        checkRep(); // checkRep needed - Check this -- CHECKED

        if (node == null)
            throw new IllegalArgumentException("!Null Node!");

        return (new_graph.containsKey(node));   // Brush up on hashCode key - value in Java
    }

    
    /**
     * Name: getAllNodes()
     * Description: Get all the nodes in graph.
     *
     * @return set of all nodes in graph
     * @spec.requires the graph != null
     */
    public Set<A> getAllNodes() {
        checkRep();
        // Collections - unmodifable? Set needed, what other features are there?
        // Lecture notes reference -> check Java dict too
        return (Collections.unmodifiableSet(new_graph.keySet())); //undmofiable set
    }


    /********************************************* EDGES ****************************************************/


    /**
     * Name: addEdge()
     * Description: Adds a new edge (ie. source, dest., label) to graph if both nodes are present in graph and edge is
     * not present already.
     *
     * @param source - edge's source node
     * @param dest   - edge's dest. node
     * @param label  - edgB label
     * @return true - if the edge successfully added to graph; otherwise, return false
     *
     * @spec.requires source != null, dest != null, label != null
     * source and dest. nodes are in the graph, edge is not present already
     * @spec.modifies this
     * @spec.effects New edge added to graph
     */
    public boolean addEdge(A source, A dest, B label) {
        checkRep(); // CHECKED

        // CONDITION: All dsl -> null & ???
        if (dest == null || source == null || label == null || !(containsNode(dest) || !(containsNode(source)))) // Reminder of containsNode conditions
            throw new IllegalArgumentException("Null Nodes & Label + Dest. & Source Nodes Need To Be In Graph");

        // Create new edge
        EdgeLabeled<A, B> new_edge = new EdgeLabeled<>(dest, label);

        if (new_graph.get(source).contains(new_edge))
            return false;

        else {
            new_graph.get(source).add(new_edge);    // Refer back to add() vs. put()
            return true;
        }
    }


    /**
     * Name: containsEdge()
     * Description: Check if edge is in graph.
     *
     * @param source - edge's source node
     * @param dest   - edge's source node
     * @param label  - edge's label
     * @return true - if edge is in graph; otherwise, return false
     * @spec.requires source != null, dest != null, label != null
     * source and dest. nodes are in the graph
     */
    public boolean containsEdge(A source, A dest, B label) {
        checkRep(); // checkRep needed - Check this -- CHECKED

        // Same condition as addEdge, reminder to add contains
        if (dest != null && label != null && source != null && containsNode(dest) && containsNode(source)) {

            EdgeLabeled<A, B> this_edge = new EdgeLabeled<>(dest, label); //
            checkRep(); // CHECKED
            return (getEdges(source).contains(this_edge)); // Refer to notes
        }

        return false;
    }

   

    /**
     * Name: getEdges()
     * Description: Get edges that connects to the given node.
     *
     * @param node - "head node" that is traced for connecting edges
     * @return set of edges that are connecting to the "head node"
     * @spec.requires node != null, node in graph
     */
    public Set<EdgeLabeled<A, B>> getEdges(A node) {
        checkRep(); //CHECKED

        //CONDITION: node can't be null and new_graph - node
        if (node == null || !(new_graph.containsKey(node)))
            throw new IllegalArgumentException();

        // else new hash set
        return (new HashSet<>(new_graph.get(node)));    //check this code!
    }

    

    /**
     * Name: getAllEdges()
     * Description: Get all the edges in graph.
     *
     * @return set of all edges in  graph
     * @spec.requires graph != null
     */
    public Set<EdgeLabeled<A,B>> getAllEdges() {
        checkRep(); // checkRep needed -- CHECKED

        // Need hashset for all edges
        Set<EdgeLabeled<A, B>> all_edges = new HashSet<>();

        // Trasnverse through new_graph
        for (A source : new_graph.keySet()) // Java key functions check
            all_edges.addAll(new_graph.get(source));

        return (all_edges);
    }

    /********************************************* OTHER METHODS ****************************************************/

    /**
     * Name: isEmpty()
     * Description: Checks if graph is empty
     *
     * @return true - if graph is empty
     */
    public boolean isEmpty() {
        checkRep(); // checkRep needed -- CHECKED
        return (new_graph.isEmpty());
    }

    /**
     * Name: size()
     * Description: Gets the number of nodes in graph.
     *
     * @return number of nodes in graph
     */
    public int size() {
        checkRep(); // checkRep needed -- CHECKED
        return (new_graph.size());
    }


    /**
     * Name: checkConnected()
     * Description: Check if two given nodes are connected by any edge
     *
     * @param source - to-be-checked source node
     * @param dest   - to-be-checked dest. node
     * @return true - if there are any edge connecting these two nodes; otherwise, return false
     * @spec.requires source != null, dest != null, source and dest. nodes are in graph
     */
    public boolean checkConnected(A source, A dest) {
        checkRep();

        // Condition same as AddNode
        if (dest != null && source != null && containsNode(dest) && containsNode(source)) {

            // Transverse through graph
            for (EdgeLabeled<A, B> label_edge : new_graph.get(source)) {    //

                if (label_edge.getDest().equals(dest))
                    return true;
            }
        }
        return false;
    }

    /**
     * Name: getChildren()
     * Description: Get the children nodes of the given node.
     *
     * @param node - trace "head node" for children nodes
     * @return set of nodes that are the children of the "head node""
     * @spec.requires node != null, node is in the graph
     */
    public Set<A> getChildren(A node) {
        checkRep();

        if (node == null || !new_graph.containsKey(node))   // USE key!!!
            throw new IllegalArgumentException();

        Set<A> children_nodes = new HashSet<>();

        // Transverse through graph - children nodes!!!
        for (EdgeLabeled<A, B> label_edge : new_graph.get(node)) // child add
            children_nodes.add(label_edge.getDest());

        return (children_nodes);
    }


    /**
     * Name: hashCode()
     * Description: hashCode function, w/ exception: when graph is null, return 0
     *
     * @return int - all objects equal to the integer will be returned
     */
    @Override
    public int hashCode() {
        checkRep(); // checkRep needed -- CHECKED

        // Condition: new_graph - null and size! - null
        if (new_graph == null || new_graph.size() == GRAPH_NULL) // Create marcovalue for GRAPH_NULL
            return GRAPH_NULL;

        return (new_graph.hashCode());
    }

    /**
     * Name: equals()
     * Description: Graph equality operation
     *
     * @param obj - to-be-compared object
     * @return true -  if object rep. the same Graph instance
     */
    @Override
    public boolean equals(Object obj) {

        // Suggestions to use >?, ?>  - Research this
        // Would instanceof work? Check this too
        if (obj instanceof Graph<?, ?>) {
            Graph<?, ?> graph = (Graph<?, ?>) obj;
            // Would this statement work? Ask TA - ASKED

            // Condition: Need to check graph sizes
            if (this.new_graph.size() != graph.size())
                return false;

            return (new_graph.equals(graph.new_graph));
        }
        return false;
    }

    /**
     * Name: toString()
     * Description: Returns a string rep. of graph.
     *
     * @return Graph's string rep.
     */
    @Override
    public String toString() {  //Something wrong here with the tests
        checkRep(); // checkRep needed -- CHECKED
        return (this.new_graph.toString());
    }

    /**
     * Name: checkRep()
     * Description: If RI (representation invariant) violated, throw an exception
     */
    private void checkRep() {   // IMPORTANT IMPLEMENTATION

        // Suggestion: assertions - check this
        assert (this.new_graph != null) : "!NULL GRAPH!";

        if (GRAPH_DEBUG) {

            // Transverse through new_graph
            for (A node : new_graph.keySet()) {

                assert (node != null) : "!NULL NODE!";

                // Need label_edge in the new_graph transversal
                for (EdgeLabeled<A, B> label_edge : new_graph.get(node)) {

                    assert (label_edge != null) : "!NULL EDGE LABEL!";  // check for null edge label

                    // These ecaliamtions points ar fun. I can';t sepell anymore :C
                    // We need to check for errors in node that don't really exist
                    assert (new_graph.containsKey(label_edge.getDest())) : "!ERROR NODE IN GRAPH!";
                }
            }
        }
    }


    /**
     * Name: EdgeLabeled
     * Description: Represents an edge w/ label and destination node.
     *
     * Ex. EdgeLabeled(node_1, edge_12) - Dest. node = node_1 amd edgB label = edge_12
     *
     * @param <A> Type of the node of EdgeLabeled
     * @param <B> Type of the edgB label of EdgeLabeled
     */
    public static class EdgeLabeled<A,B> {

        public static final boolean GRAPH_DEBUG = true;         // Debug flag for checkRep()
        private final A dest_node;                              // Edge's destination node
        private final B edge_label;                             // Edge's Label

        /* Abstraction Function:
           AF(this) = Labeled edgB label_edge w/o source code such that:
                      label_edge.edge_label = edge's edgB label
                      label_edge.dest = edge's dest. node

         Representation Invariant:
            Destination node not equal to null and edgB label is not equal to null
        */
        

        /**
         * Name: EdgeLabeled()
         * Description: Creates a labeled edge.
         *
         * @param dest_node  - edge's dest.
         * @param edge_label - edge's edgB label
         * @spec.requires dest != null, edge_label != null
         * @spec.effects Creates a new labeled edge e w/ e.dest = dest and e.edge_label = edge_label
         */
        public EdgeLabeled(A dest_node, B edge_label) {

            // Condition: Check if parameters are null, else update this.
            if (dest_node == null || edge_label == null)
                throw new IllegalArgumentException();

            // Check updated - dest node and edge label
            this.dest_node = dest_node;
            this.edge_label = edge_label;
            checkRep(); // CHECKED
        }

        /**
         * Name: getEdgeLabel()
         * Description: Get edgB label of edge.
         *
         * @return Edge's edgB label
         */
        public B getEdgeLabel() {
            checkRep(); //checkRep needed -- CHECKED
            return (this.edge_label);
        }


        /**
         * Name: getDest()
         * Description: GeA dest. node of edge.
         *
         * @return Edge's dest. node
         */
        public A getDest() {
            checkRep(); //checkRep needed -- CHECKED
            return (this.dest_node);
        }

        /**
         * Name: hashCode()
         * Description: hashCode function.
         *
         * @return int - return all objects equal to this integer
         */
        @Override
        public int hashCode() {
            checkRep(); // checkRep needed -- CHECKED

            // It should multiply - reminder hashTables
            return (this.edge_label.hashCode() * this.dest_node.hashCode());
        }

        /**
         * Name: equals()
         * Description: Equality operation.
         *
         * @param compare_obj - to-be-compared object
         * @return true - if the object represents the same edgB label and destination
         */
        @Override
        public boolean equals(Object compare_obj) {
            checkRep(); //checkRep needed, there gotta be a better method x2 sentiments

            // Refer to research of <?,?>, gotta do more - refer to that function too
            if (!(compare_obj instanceof EdgeLabeled<?, ?>))
                return false;

            // check this function, should be similar
            EdgeLabeled<?, ?> label_edge = (EdgeLabeled<?, ?>) compare_obj;

            checkRep(); // needed? -- CHECKED

            // Create variables to check "equals"
            boolean edge_label_equal = this.edge_label.equals(label_edge.edge_label);
            boolean dest_node_equal = this.dest_node.equals(label_edge.dest_node);

            // We need to return boolean, so it should be if the two vars are "equal"
            return (edge_label_equal && dest_node_equal);
        }


        /**
         * Name: toString()
         * Description: Returns edge's string rep.
         *
         * @return string representation of the edge
         */
        @Override
        public String toString() {
            checkRep(); //checkRep needed -- CHECKED

            // Print out the string rep using [] - EDIT: CHANGED to () to avoid confusion
            String edge_string_rep = "(" + this.dest_node + "," + this.edge_label + ")";

            checkRep(); //checkRep needed again? - check this

            return edge_string_rep;
        }


        /**
         * Name: checkRep()
         * Description: If the RI (representation invariant) violated, throw an exception
         */
        private void checkRep() {
            // Check assert statements
            // Null edge label
            assert (edge_label != null) : "!NULL EDGE LABEL!";
            // NUll dest node
            assert (dest_node != null) : "!NULL DEST NODE!";
        }
    }
}