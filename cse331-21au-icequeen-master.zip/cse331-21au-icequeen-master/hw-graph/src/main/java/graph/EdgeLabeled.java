package graph;

// Import the libraries

import java.util.Set;
import java.util.HashSet;
import java.util.HashMap;
import java.util.Collections;

/**
 * Name: EdgeLabeled
 * Description: Represents an edge w/ label and destination node.
 *
 * Ex. EdgeLabeled(node_1, edge_12) - Dest. node = node_1 amd edgB label = edge_12
 *
 * @param <A> Type of the node of EdgeLabeled
 * @param <B> Type of the edgB label of EdgeLabeled
 */

public class EdgeLabeled<A, B> {

    public static final boolean GRAPH_DEBUG = true;         // Debug flag for checkRep()
    private final A source_node;                            // Edge's source node
    private final A dest_node;                              // Edge's destination node
    private final B edge_label;                             // Edge's Label

    /* Abstraction Function:
       AF(this) = Labeled edge label_edge w/o source code such that:
                  label_edge.source = edge's source node
                  label_edge.dest = edge's dest. node
                  label_edge.edge_label = edge's edge label
                  

     Representation Invariant:
        Destination node not equal to null and edge label is not equal to null
    */


    /**
     * Name: EdgeLabeled()
     * Description: Creates a labeled edge.
     *
     * @param source  - edge's source
     * @param dest  - edge's dest.
     * @param label - edge's edgB label
     * @spec.requires source != null, dest != null, edge_label != null
     * @spec.effects Creates a new labeled edge e w/ e.source_node = source, 
     *               e.dest_node = dest, and e.edge_label = edge_label
     */
    
    public EdgeLabeled(A source, A dest, B label) {

        // Condition: Check if parameters are null, else update this.
        if (source == null || dest == null || label == null)
            throw new IllegalArgumentException();
        
        this.source_node = source;
        this.dest_node = dest;
        this.edge_label = label;
        
        // checkRep needed - Check this -- CHECKED
        // checkRep();
    }

    /**
     * Name: getSource()
     * Description: Get source node of edge.
     *
     * @return Edge's source node
     */
    public A getSource() {

        // checkRep needed - Check this -- CHECKED
        // checkRep();

        return (this.source_node);
    }

    /**
     * Name: getDest()
     * Description: GeA dest. node of edge.
     *
     * @return Edge's dest. node
     */
    public A getDest() {

        // checkRep needed - Check this -- CHECKED
        // checkRep();

        return (this.dest_node);
    }

    /**
     * Name: getEdgeLabel()
     * Description: Get edgB label of edge.
     *
     * @return Edge's edgB label
     */
    public B getLabel() {

        // checkRep needed - Check this -- CHECKED
        // checkRep();

        return (this.edge_label);
    }


    /**
     * Name: hashCode()
     * Description: hashCode function.
     *
     * @return int - return all objects equal to this integer
     */
    public int hashCode() {

        // checkRep needed - Check this -- CHECKED
        // checkRep();

        // Use addition for the hashCode()
        return (source_node.hashCode() + dest_node.hashCode() + edge_label.hashCode());
    }

    /**
     * Name: equals()
     * Description: Equality operation.
     *
     * @param compare_obj - to-be-compared object
     * @return true - if the object represents the same edgB label and destination
     */
    public boolean equals(Object compare_obj) {

        // Suggestions to use >?, ?>  - Research this
        // Would instanceof work? Check this too


        if (compare_obj instanceof graph.EdgeLabeled<?, ?>) {

            checkRep();  //checkRep needed, there gotta be a better method x2 sentiments

            // Refer to research of <?,?>, gotta do more - refer to that function too
            graph.EdgeLabeled<?, ?> edge = (graph.EdgeLabeled<?, ?>) compare_obj;

            // Create variables to check "equals"
            boolean sourceEqual = source_node.equals(edge.source_node);
            boolean destEqual =  dest_node.equals(edge.dest_node);
            boolean labelEqual = edge_label.equals(edge.edge_label);

            // We need to return boolean, so it should be if the two vars are "equal"
            return (sourceEqual &&destEqual && labelEqual);
        }

        checkRep(); // needed? -- CHECKED
        return false;
    }

    /**
     * Name: toString()
     * Description: Returns edge's string rep.
     *
     * @return string representation of the edge
     */
    public java.lang.String toString() {
        checkRep(); //checkRep needed -- CHECKED

        // Print out the string rep using [] - EDIT: CHANGED to () to avoid confusion
        // EDIT 2 - Removed the () completely - Just too messy
        return source_node + ", label: " + edge_label + ", " + dest_node;
    }

    /**
     * Name: checkRep()
     * Description: If the RI (representation invariant) violated, throw an exception
     */
    private void checkRep() {
        // Check assert statements

        // Null source label
        assert (!source_node.equals(null)): "!NULL SOURCE NODE!";;

        // NUll dest node
        assert (!dest_node.equals(null)) : "!NULL DEST NODE!";;

        // Null edge label
        assert (!edge_label.equals(null)) : "!NULL EDGE LABEL!";;
    }
}