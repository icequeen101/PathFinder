package graph;

// Import the libraries

import java.util.Set;
import java.util.HashSet;
import java.util.HashMap;
import java.util.Collections;

/**
 * Name: Graph - Class
 * Description: Class that represents a directed and mutable new_graph.
 * It includes a collection of nodes and edges, where each edge contains a dest. node and the edgB label.
 *
 * @param <A> The type of nodes in the Graph
 * @param <B> The type of edges in the Graph
 */

public class UpdatedGraph<A, B> {

    public static final boolean GRAPH_DEBUG = false;                    // GRAPH_DEBUG flag for checkRep()
    public static final int GRAPH_NULL = 0;                             // Graph Null Macro-value

    private final HashMap<A, HashSet<EdgeLabeled<A, B>>> new_graph;     // Graph: Contain nodes & their connecting edges w/ labels.

  /* Abstraction Function (AF):
        AF(this) = Graph new_graph
            new_graph = {} -> empty graph
            new_graph = {node_1 = [],...} -> node_1 has no outgoing edges
            new_graph = {node_1 = [(node_2, edge_12), (node_3, edge_13),...], node_2 = [...], node_3 = [...],...}
                        -> edge_12's & edge_13's dest. nodes are node_2 & node_3 outgoing from node_1

        IGNORE THIS Note: I used the dormat [[node1, edge_12]] in the code and I am too lazy to fix it.
        Edit: I fixed it.

     Representation Invariant (RI):
        Graph is not equal to null, each edge/node is not equal to null, & graph must have the node & edgB labels
        included

     */

    /**
     * Name: Graph()
     * Description: Creates an empty directed labeled new_graph.
     *
     * @spec.effects Creates an empty directed labeled graph
     */

    /**
     * @spec.effects Constructs an empty directed labeled graph
     */
    public UpdatedGraph() {
        new_graph = new HashMap<>();

        // checkRep needed - Check this -- CHECKED
        // checkRep();
    }


    /********************************************* NODES ****************************************************/


    /**
     * Name: addNode()
     * Description: Add new node to graph, if node is not already in graph
     *
     * @param node - node to-be-added to graph
     * @return true - if node successfully added to graph; otherwise, return false
     * @spec.requires node != null
     * @spec.modifies this
     * @spec.effects node added to graph, if node not already present in graph
     */
    public boolean addNode(A node) {

        // checkRep needed - Check this -- CHECKED
        // checkRep();

        if (!containsNode(node)) {
            new_graph.put(node, new HashSet<>()); // Use put()

            // checkRep();  // CHECKED

            return true;

        } else {

            // throw new IllegalArgumentException("Null Node");
            // checkRep(); // CHECKED

            return false;
        }
    }


    /**
     * Name: containsNode()
     * Description: Check if node is in graph.
     *
     * @param node - check if node is in graph
     * @return true - if the node is in graph; otherwise, return false
     * @spec.requires node != null
     */
    public boolean containsNode(A node) {

        // checkRep needed - Check this -- CHECKED
        // checkRep();

        if (new_graph.containsKey(node))  // Brush up on hashCode key - value in Java
            return true;

         else

            // throw new IllegalArgumentException("!Null Node!");
            // Need checkrep() ?

            return false;
    }

    /**
     * Name: getAllNodes()
     * Description: Get all the nodes in graph.
     *
     * @return set of all nodes in graph
     * @spec.requires the graph != null
     */
    public Set<A> getAllNodes() {

        // checkRep needed - Check this -- CHECKED
        // checkRep();

        return (new HashSet<A>(new_graph.keySet()));
    }

    /********************************************* EDGES ****************************************************/

    /**
     * Name: addEdge()
     * Description: Adds a new edge (ie. source, dest., label) to graph if both nodes are present in graph and edge is
     * not present already.
     *
     * @param source - edge's source node
     * @param dest   - edge's dest. node
     * @param label  - edgB label
     * @return true - if the edge successfully added to graph; otherwise, return false
     *
     * @spec.requires source != null, dest != null, label != null
     * source and dest. nodes are in the graph, edge is not present already
     * @spec.modifies this
     * @spec.effects New edge added to graph
     */

    public boolean addEdge(A source, A dest, B label) {

        // checkRep needed - Check this -- CHECKED
        // checkRep();

        EdgeLabeled<A, B> new_edge = new EdgeLabeled<>(source, dest, label);
        boolean sourceKey = new_graph.containsKey(source);
        boolean destKey = new_graph.containsKey(dest);
        boolean labelExist = new_graph.get(dest).contains(new_edge.getLabel());

        if (sourceKey && destKey && !(labelExist)) {

            new_graph.get(source).add(new_edge);

            // checkRep(); // CHECKED

            return true;

        } else

            // throw new IllegalArgumentException("Null Nodes & Label + Dest. & Source Nodes Need To Be In Graph");
            // checkRep(); // CHECKED

            return false;

    }

    /**
     * Name: containsEdge()
     * Description: Check if edge is in graph.
     *
     * @param source - edge's source node
     * @param dest   - edge's source node
     * @param label  - edge's label
     * @return true - if edge is in graph; otherwise, return false
     * @spec.requires source != null, dest != null, label != null
     * source and dest. nodes are in the graph
     */
    public boolean containsEdge(A source, A dest, B label) {

        // checkRep needed - Check this -- CHECKED
        // checkRep();

        EdgeLabeled<A, B> edge = new EdgeLabeled<>(source, dest, label);
        boolean edgeExist = getEdges(source).contains(edge);

        // Similar condition as addEdge, reminder to add contains
        if (containsNode(source) && containsNode(dest) && edgeExist)
            return true;

         else

            // throw new IllegalArgumentException("ERROR");
            // checkRep(); // CHECKED

            return false;

    }

    /**
     * Name: getEdges()
     * Description: Get edges that connects to the given node.
     *
     * @param node - "head node" that is traced for connecting edges
     * @return set of edges that are connecting to the "head node"
     * @spec.requires node != null, node in graph
     */
    public Set<EdgeLabeled<A, B>> getEdges(A node) {

        // checkRep needed - Check this -- CHECKED
        // checkRep();

        HashSet<EdgeLabeled<A, B>> new_edges = new HashSet<>();

        // CONDITION: node can't be null and new_graph - node
        if (containsNode(node))

            // TRAVERSE: Check edges in node list
            for (EdgeLabeled<A, B> edge : new_graph.get(node))
                new_edges.add(edge);

        // else: throw new IllegalArgumentException();

        return new_edges;
    }

    /**
     * Name: getAllEdges()
     * Description: Get all the edges in graph.
     *
     * @return set of all edges in  graph
     * @spec.requires graph != null
     */
//    public Set<Graph.EdgeLabeled<A,B>> getAllEdges() {
//        // checkRep(); // checkRep needed -- CHECKED
//
//        // Need hashset for all edges
//        Set<Graph.EdgeLabeled<A, B>> all_edges = new HashSet<>();
//
//        // Trasnverse through new_graph
//        for (A source : new_graph.keySet()) // Java key functions check
//            all_edges.addAll(new_graph.get(source));
//
//        return (all_edges);
//    }


    /********************************************* OTHER METHODS ****************************************************/



    /**
     * Name: isEmpty()
     * Description: Checks if graph is empty
     *
     * @return true - if graph is empty
     */
    public boolean isEmpty() {

        // checkRep needed -- CHECKED
        // checkRep();

        return (new_graph.isEmpty());
    }

    /**
     * Name: size()
     * Description: Gets the number of nodes in graph.
     *
     * @return number of nodes in graph
     */
    public int size() {

        // checkRep needed -- CHECKED
        // checkRep();

        return (new_graph.size());
    }

    /**
     * Name: checkConnected()
     * Description: Check if two given nodes are connected by any edge
     *
     * @param source - to-be-checked source node
     * @param dest   - to-be-checked dest. node
     * @return true - if there are any edge connecting these two nodes; otherwise, return false
     * @spec.requires source != null, dest != null, source and dest. nodes are in graph
     */
//    public boolean checkConnected(A source, A dest) {
//        checkRep();
//
//        // Condition same as AddNode
//        if (dest != null && source != null && containsNode(dest) && containsNode(source)) {
//
//            // Transverse through graph
//            for (Graph.EdgeLabeled<A, B> label_edge : new_graph.get(source)) {    //
//
//                if (label_edge.getDest().equals(dest))
//                    return true;
//            }
//        }
//        return false;
//    }



    /**
     * Name: getChildren()
     * Description: Get the children nodes of the given node.
     *
     * @param node - trace "head node" for children nodes
     * @return set of nodes that are the children of the "head node""
     * @spec.requires node != null, node is in the graph
     */
    public Set<A> getChildren(A node) {

        // checkRep needed -- CHECKED
        // checkRep();

        Set<EdgeLabeled<A, B>> new_edges = getEdges(node);
        HashSet<A> children_nodes = new HashSet<>();

        // Transverse through graph - children nodes!!!
        for (EdgeLabeled<A, B> edge : new_edges)
            children_nodes.add(edge.getDest());    // child add

        return (children_nodes);
    }

    /**
     * Name: hashCode()
     * Description: hashCode function, w/ exception: when graph is null, return 0
     *
     * @return int - all objects equal to the integer will be returned
     */
    @Override
    public int hashCode() {

        // checkRep needed -- CHECKED
        // checkRep();

        // Condition: new_graph - null and size! - null
        if (new_graph == null || new_graph.size() == GRAPH_NULL) // Create marcovalue for GRAPH_NULL
            return GRAPH_NULL;

        return (new_graph.hashCode());
    }


    /**
     * Name: equals()
     * Description: Graph equality operation
     *
     * @param obj - to-be-compared object
     * @return true -  if object rep. the same Graph instance
     */
    @Override
    public boolean equals(Object obj) {

        boolean graphsEquals;

        // Suggestions to use <?, ?>  - Research this
        // Would instanceof work? Check this too

        if (obj instanceof UpdatedGraph) {

            UpdatedGraph<?, ?> graph = (UpdatedGraph<?, ?>) obj;
            // Would this statement work? Ask TA - ASKED

            graphsEquals = new_graph.equals(graph.new_graph);

            // checkRep needed -- CHECKED
            // checkRep();

            return graphsEquals;
        }

        // checkRep(); // CHECKED

        return false;
    }


    /**
     * Name: toString()
     * Description: Returns a string rep. of graph.
     *
     * @return Graph's string rep.
     */
    @Override
    public String toString() {  // Something wrong here with the tests

        // checkRep needed -- CHECKED
        // checkRep();

        return (this.new_graph.toString());
    }


    /**
     * Name: checkRep()
     * Description: If RI (representation invariant) violated, throw an exception
     */

  /*  private void checkRep() {

        // Suggestion: assertions - check this
        assert (this.new_graph != null) : "!NULL GRAPH!";

        //  if (GRAPH_DEBUG) {

        // TRAVERSE nodes in graph
        for(A node: new_graph.keySet()) {   // Java dictionary for keySet() - Read

            assert(node != null) : "!NULL NODE!";

            for(EdgeLabeled<A,B> edge:new_graph.get(node)) {

                // Exclamation points... NEED TO MAKE IT BIG. Tired, spelling is ...

                assert(edge != null) : "!NULL EDGE LABEL!";  // check for null edge label

                // We need to check for errors in node that don't really exist
                assert(new_graph.containsKey(edge.getDest()))  : "!ERROR NODE IN GRAPH!";
            }
        }
    }*/

    /*

    OLD checkRep()

     */

   /* private void checkRep() {   // IMPORTANT IMPLEMENTATION

        // Suggestion: assertions - check this
        assert (this.new_graph != null) : "!NULL GRAPH!";

        if (GRAPH_DEBUG) {

            // Transverse through new_graph
            for (A node : new_graph.keySet()) {

                assert (node != null) : "!NULL NODE!";

                // Need label_edge in the new_graph transversal
                for (Graph.EdgeLabeled<A, B> label_edge : new_graph.get(node)) {

                    assert (label_edge != null) : "!NULL EDGE LABEL!";  // check for null edge label

                    // These ecaliamtions points ar fun. I can';t sepell anymore :C
                    // We need to check for errors in node that don't really exist
                    assert (new_graph.containsKey(label_edge.getDest())) : "!ERROR NODE IN GRAPH!";
                }
            }
        }*/

}
