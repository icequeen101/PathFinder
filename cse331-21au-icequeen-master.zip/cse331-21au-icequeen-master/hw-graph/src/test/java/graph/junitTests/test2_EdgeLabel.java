package graph.junitTests;

// Import all the libraries
import graph.Graph.EdgeLabeled;
import org.junit.rules.Timeout;
import org.junit.Before;
import org.junit.Test;
import org.junit.Rule;
import java.util.Set;
import java.util.HashSet;

import static org.junit.Assert.*;


public class test2_EdgeLabel {

    @Rule
    //copy over from test1
    public Timeout timer = Timeout.seconds(10);

    // create the edge labels
    private EdgeLabeled<String, String> edge1;
    private EdgeLabeled<String, String> edge_2;
    private EdgeLabeled<String, String> edge_3;
    private EdgeLabeled<String, String> temp_edge; // createed temp_edge for lalter use

    /********************************************* Init Tests  *************************************************/

    @Before
    // need init() - look at test1 *suggested
    public void init() throws Exception {
        edge1 = new EdgeLabeled<>("", "");
        edge_2 = new EdgeLabeled<>("x", "xx"); // we are gonna use the genomic x & y
        edge_3 = new EdgeLabeled<>("y", "xy"); // i'm dead so my creativity is amzing
    }

    /********************************************* Constructor Tests  *************************************************/

    // Constructor w/ dest = null TEST
    @Test(expected = IllegalArgumentException.class) // Suggested command, check this with TA and Google
    public void createEdges_nullDest_test() {   // create edges with a null destation node
        new EdgeLabeled<>(null, "xx");
    }

    // Constructor w/ edge_label = null TEST
    @Test(expected = IllegalArgumentException.class) // similar to above with constructor use
    public void createEdges_nullEL_test() { // EL for edge label b/c its too long otherwise
        // create edges with the null edge label
        new EdgeLabeled<>("x", null);
    }

    /********************************************* Getters Tests  *************************************************/

    // getDest() TEST
    @Test
    public void getDest_test() {
        // assert equal - check dest
        assertEquals("", edge1.getDest());  // check empty, x , and y
        assertEquals("x", edge_2.getDest());
        assertEquals("y", edge_3.getDest());
    }


    //  getEdgeLabel() TEST
    @Test
    public void getEdgeLabel_test() {
        // asssert equal - el
        assertEquals("", edge1.getEdgeLabel()); // check empty, xx , and yy
        assertEquals("xx", edge_2.getEdgeLabel());
        assertEquals("xy", edge_3.getEdgeLabel());
    }

    /********************************************* Equals Tests  *************************************************/

    //  equals() TEST
    @Test
    public void equals_test1() { // "reflecive equality"
        assertTrue(edge1.equals(edge1)); // self equal check
    }


    @Test
    public void equals_test2() { // all should be true
        edge_2 = new EdgeLabeled<>("", ""); // check between edge 1 and edge 2
        assertTrue(edge1.equals(edge_2)); //"symmertry equality"
        assertTrue(edge_2.equals(edge1));
    }


    @Test
    public void equals_test3() { // all should be true
        edge_2 = new EdgeLabeled<>("", ""); // check between 3 edges
        edge_3 = new EdgeLabeled<>("", ""); //" transitive equality"
        assertTrue(edge1.equals(edge_2)); // 1 to 2
        assertTrue(edge_2.equals(edge_3)); // 2 to 3
        assertTrue(edge_3.equals(edge1)); // 3 to 1
    }

    public void equals_test4() { // not highlighted?
        temp_edge = new EdgeLabeled<>("yy", "yy"); // create temp_edge, back to private vars
        assertFalse(edge_3.equals(temp_edge)); // checke with different edge
    }


    @Test
    public void equals_test5() { // check with dsame edge
        temp_edge = new EdgeLabeled<>("y", "xy"); // should be yy to xy - check notes?
        assertTrue(edge_3.equals(temp_edge));
    }

    /************************************* HashCode & Other Method Tests  ******************************************/

    @Test
    public void sameEdge_Hashcode_test() { //check same edge for hash code
        assertEquals(new EdgeLabeled<>("y", "xy").hashCode(), edge_3.hashCode());
    }

    // test toString() method
    @Test
    public void toString_test() { // Use square brackets - switch to round?
        assertEquals("(,)", edge1.toString());
        assertEquals("(x,xx)", edge_2.toString());
        assertEquals("(y,xy)", edge_3.toString());
    }
}