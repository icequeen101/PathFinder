package graph.junitTests;

// Import all the libraries

import static org.junit.Assert.*;

import graph.Graph;
import org.junit.rules.Timeout;
import org.junit.Before;
import org.junit.Test;
import org.junit.Rule;
import java.util.Set;
import java.util.HashSet;

// BEGIN TEST CODE FOR GRAPH

public class test1_Graph {

    @Rule
    // Use timer, suggested by Mike
    // Timeout in HE5 - Part2
    public Timeout timer = Timeout.seconds(10); //each test run 10 secs

    // Tests Objects
    private Graph<String, String> graph_1, graph_2, graph_3;
    private Set<String> node_1, node_2, node_3;
    private Set<Graph.EdgeLabeled<String, String>> edge_1, edge_2, edge_3;

    //private Graph.EdgeLabeled<String, String> temp_edge1; // created temp_edge for later use
    //private Graph.EdgeLabeled<String, String> temp_edge2; // created temp_edge for later use


    /********************************************* Initialization *************************************************/

    @Before
    public void init() throws Exception {

        // Create graphs 1-3
        graph_1 = new Graph<>();
        graph_2 = new Graph<>();
        graph_3 = new Graph<>();

        // Create graph 1's stuff
        node_1 = new HashSet<>();   // new Hashset needed
        edge_1 = new HashSet<>();

        // Create graph 2's stuff
        node_2 = new HashSet<>();
        edge_2 = new HashSet<>();

        // Create graph 3's stuff
        node_3 = new HashSet<>();
        edge_3 = new HashSet<>();

        // Create the graph nodes - graph 2
        graph_2.addNode("node1");
        node_2.add("node1");    // add to node2 too

        // Create the graph nodes - graph 3
        graph_3.addNode("node1");
        graph_3.addNode("node2");
        graph_3.addNode("node3");

        // create node_3
        node_3.add("node1");
        node_3.add("node2");
        node_3.add("node3");

        // Create graph 3 edges
        graph_3.addEdge("node1", "node1", "edge11");
        graph_3.addEdge("node1", "node2", "edge12");
        graph_3.addEdge("node2", "node2", "edge22");
        graph_3.addEdge("node2", "node3", "edge23");
        graph_3.addEdge("node3", "node1", "edge31");
        graph_3.addEdge("node3", "node3", "edge33");

        // Create graph 3 edges - labels
        edge_3.add(new Graph.EdgeLabeled<>("node1", "edge11"));
        edge_3.add(new Graph.EdgeLabeled<>("node2", "edge12"));
        edge_3.add(new Graph.EdgeLabeled<>("node2", "edge22"));
        edge_3.add(new Graph.EdgeLabeled<>("node3", "edge23"));
        edge_3.add(new Graph.EdgeLabeled<>("node1", "edge31"));
        edge_3.add(new Graph.EdgeLabeled<>("node3", "edge33"));
    }

    /********************************************* Empty Tests  *************************************************/


    // isEmpty() method TEST - check that graphs are empty
    @Test
    public void isEmpty_test1() {
        assertTrue(graph_1.isEmpty());  // graph1 true
        assertFalse(graph_2.isEmpty()); // others false
        assertFalse(graph_3.isEmpty()); // g2 & g3
    }

    // isEmpty() method TEST - before and after adding nodes
    @Test
    public void isEmpty_test2() {
        // BEFORE NODE ADDED
        assertTrue(graph_1.isEmpty());  //graph1 true
        assertFalse(graph_2.isEmpty()); // others false
        assertFalse(graph_3.isEmpty());

         // AFTER
        graph_1.addNode("node9");   //// use node 9 for luck number 9
        graph_2.addNode("node9");   // add to all graphs
        graph_3.addNode("node9");
        // should all be false cause we added stuff
        assertFalse(graph_1.isEmpty());
        assertFalse(graph_2.isEmpty());
        assertFalse(graph_3.isEmpty());
    }

    /********************************************* Contain Tests  *************************************************/

    //  containsEdge() method TEST
    @Test
    public void containsEdge_test1() {

        // create true for this edge
        assertTrue(graph_3.containsEdge("node1", "node1", "edge11"));

        // check all should be not true
        assertFalse(graph_1.containsEdge("node1", "node1", "edge11"));
        assertFalse(graph_2.containsEdge("node1", "node1", "edge11"));

        assertFalse(graph_3.containsEdge("node2", "node3", "edge9"));
        assertFalse(graph_3.containsEdge("node9", "node9", "edge99"));
    }

    //  containsEdge() method TEST - before and after adding edges
    @Test
    public void containsEdge_test2() {
        assertFalse(graph_2.containsEdge("node1", "node1", "edge11")); // check for false
        graph_2.addEdge("node1", "node1", "edge11");
        assertTrue(graph_2.containsEdge("node1", "node1", "edge11")); // should be true for graph2
    }


    //  containsNode() method TEST
    @Test
    public void containNode_test1() {
        // check nodes half true - half false
        assertFalse(graph_1.containsNode("node1")); // false - use node 1
        assertTrue(graph_2.containsNode("node1")); // true
        assertTrue(graph_3.containsNode("node1")); // true
        assertFalse(graph_2.containsNode("node3")); // false - use node 2
        assertTrue(graph_3.containsNode("node3")); // true
        assertFalse(graph_3.containsNode("node9")); // false - use node 9! Test for nonexistent node
    }

    // containsNode() method TEST - before and after adding nodes
    @Test
    public void containNode_test2() {
        // BEFORE NODE ADDED

        //check all false
        assertFalse(graph_1.containsNode("node9")); // use node9
        assertFalse(graph_2.containsNode("node9"));
        assertFalse(graph_3.containsNode("node9"));

         // AFTER
        graph_1.addNode("node9");
        graph_2.addNode("node9");
        graph_3.addNode("node9");

        // check all true
        assertTrue(graph_1.containsNode("node9")); // since we added nodes
        assertTrue(graph_2.containsNode("node9"));
        assertTrue(graph_3.containsNode("node9"));
    }

    /********************************************* GetEdges Tests  *************************************************/

    // getEdges() method TEST - check front node - head node
    @Test
    public void getEdges_test1() {
        assertTrue(graph_2.getChildren("node1").isEmpty());
        edge_3 = new HashSet<>();
        // get node1-2 to node 3
        //temp_edge = new Graph.EdgeLabeled<>("node_2", "edge_12");
        edge_3.add(new Graph.EdgeLabeled<>("node2", "edge12"));  // check node_2
        edge_3.add(new Graph.EdgeLabeled<>("node1", "edge11"));
        assertEquals(edge_3, graph_3.getEdges("node1"));
    }

    // getAllEdges() method TEST
    @Test
    public void getEdges_test2() {
        // add edges to all graphs resp.
        assertEquals(edge_1, graph_1.getAllEdges());
        assertEquals(edge_2, graph_2.getAllEdges());
        assertEquals(edge_3, graph_3.getAllEdges());
    }

    // getAllEdges() TEST - before and after adding edges
    @Test
    public void getEdges_test3() {
        assertEquals(edge_2, graph_2.getAllEdges());
        graph_2.addEdge("node1", "node1", "edge1"); // self-loop - all node_1
        edge_2.add(new Graph.EdgeLabeled<>("node1", "edge1"));
        assertEquals(edge_2, graph_2.getAllEdges());
    }


    /********************************************* All Tests  *************************************************/




    // getAllNodes() method TEST
    @Test
    public void allNodes_test1() {
        assertEquals(node_1, graph_1.getAllNodes()); // node and graph resp.
        assertEquals(node_2, graph_2.getAllNodes());
        assertEquals(node_3, graph_3.getAllNodes());
    }

    // getAllNodes() method TEST - before and after adding nodes
    @Test
    public void allNodes_test2() {
        assertEquals(node_1, graph_1.getAllNodes()); //check for node_1 and graph_1
        graph_1.addNode("node9"); // use node 9
        node_1.add("node9");
        assertEquals(node_1, graph_1.getAllNodes());
    }

    /********************************************* Connected Tests  *************************************************/

    //  checkConnected() method TEST - test on nodes
    @Test
    public void checkConnected_test1() {
        // check connection for node 1
        assertFalse(graph_2.checkConnected("node1", "node1")); // check 1-2
        assertTrue(graph_3.checkConnected("node1", "node2")); // reverse should be true
        assertFalse(graph_3.checkConnected("node100", "node2")); //create node_100 - should be false
    }

    // checkConnected() TEST - before and after adding nodes
    @Test
    public void checkConnected_test2() {
        // check connection
        assertFalse(graph_2.checkConnected("node1", "node1")); // should assert false, then add
        graph_2.addEdge("node1", "node1", "edge11");
        assertTrue(graph_2.checkConnected("node1", "node1")); // become true
    }

    /********************************************* Children Tests  *************************************************/


    // getChildren() method TEST - check the children nodes for the "head node"
    @Test
    public void children_test1() {
        assertTrue(graph_2.getChildren("node1").isEmpty()); // check children - refer to notes
        node_3 = new HashSet<>(); // need to create new hashset
        node_3.add("node1"); // use node 3 to add other nodes
        node_3.add("node2");
        assertEquals(node_3, graph_3.getChildren("node1"));
    }


    /*************************************** HashCode & Other Method Tests  *****************************************/

    // hashCode() method TEST - Same edges/nodes
    @Test
    public void hashcode_test() {
        graph_1 = new Graph<>(); // create graph
        graph_1.addNode("node1"); // use graph1 for same edges abd nodes - nodes 1
        assertEquals(graph_2.hashCode(), graph_1.hashCode());
    }

    //  equals() method TEST - Same edges/nodes
    @Test
    public void equal_test() {
        graph_1 = new Graph<>(); // refer to hasCode
        graph_1.addNode("node1");  // need to check for equal - node 1 -- graph 2 and graph 1
        assertTrue(graph_2.equals(graph_1));
    }

    // size() method TEST
    @Test
    public void size_test1() {
        assertEquals(0, graph_1.size()); // check graph size 1-3
        assertEquals(1, graph_2.size()); //
        assertEquals(3, graph_3.size()); // 0-3
    }

    // size() method TEST - before and after adding nodes
    @Test
    public void size_test2() {

        // BEFORE NODES ADDED - assertEquals
        assertEquals(0, graph_1.size());    // similar to size_test1
        assertEquals(1, graph_2.size());    // change expected values
        assertEquals(3, graph_3.size());

        // AFTER
        graph_1.addNode("node9"); // refer to emptysize test 2
        graph_2.addNode("node9");
        graph_3.addNode("node9");
        assertEquals(1, graph_1.size()); // check sizes
        assertEquals(2, graph_2.size());  // sizes difference - CHECKED
        assertEquals(4, graph_3.size());
    }


    // toString() method TEST
    @Test
    public void testToString() {
        // useing the precious design with [] and _ caused some extra design complexities
        // thus, resdesigned

        assertEquals("{}", graph_1.toString());
        assertEquals("{node1=[]}", graph_2.toString());
        assertEquals("{node2=[(node2,edge22), (node3,edge23)], " +  // set node2
                "node3=[(node1,edge31), (node3,edge33)], " +                // node3
                "node1=[(node2,edge12), (node1,edge11)]}", graph_3.toString()); // to graph 3
    }

}