/*
 * Copyright (C) 2021 Kevin Zatloukal.  All rights reserved.  Permission is
 * hereby granted to students registered for University of Washington
 * CSE 331 for use solely during Spring Quarter 2021 for purposes of
 * the course.  No other use, copying, distribution, or modification
 * is permitted without prior written consent. Copyrights for
 * third-party components of this work must be honored.  Instructors
 * interested in reusing these course materials should contact the
 * author.
 */

package graph.scriptTestRunner;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import java.util.*;

import graph.Graph;

/**
 * This class implements a testing driver which reads test scripts
 * from files for testing Graph.
 **/
public class GraphTestDriver {

    // ***************************
    // ***  JUnit Test Driver  ***
    // ***************************

    /**
     * String -> Graph: maps the names of graphs to the actual graph
     **/
    // TODO for the student: Uncomment and parameterize the next line correctly:
    private final Map<String, Graph<String, String>> graphs = new HashMap<>();  // Figure this out!!!! Why is it red>

    private final PrintWriter output;
    private final BufferedReader input;

    /**
     * @spec.requires r != null && w != null
     * @spec.effects Creates a new GraphTestDriver which reads command from
     * {@code r} and writes results to {@code w}
     **/
    // Leave this constructor public
    public GraphTestDriver(Reader r, Writer w) {
        input = new BufferedReader(r);
        output = new PrintWriter(w);
    }

    /**
     * @throws IOException if the input or output sources encounter an IOException
     * @spec.effects Executes the commands read from the input and writes results to the output
     **/
    // Leave this method public
    public void runTests() throws IOException {
        String inputLine;
        while ((inputLine = input.readLine()) != null) {
            if ((inputLine.trim().length() == 0) ||
                    (inputLine.charAt(0) == '#')) {
                // echo blank and comment lines
                output.println(inputLine);
            } else {
                // separate the input line on white space
                StringTokenizer st = new StringTokenizer(inputLine);
                if (st.hasMoreTokens()) {
                    String command = st.nextToken();

                    List<String> arguments = new ArrayList<>();
                    while (st.hasMoreTokens()) {
                        arguments.add(st.nextToken());
                    }

                    executeCommand(command, arguments);
                }
            }
            output.flush();
        }
    }

    private void executeCommand(String command, List<String> arguments) {
        try {
            switch (command) {
                case "CreateGraph":
                    createGraph(arguments);
                    break;
                case "AddNode":
                    addNode(arguments);
                    break;
                case "AddEdge":
                    addEdge(arguments);
                    break;
                case "ListNodes":
                    listNodes(arguments);
                    break;
                case "ListChildren":
                    listChildren(arguments);
                    break;
                default:
                    output.println("Unrecognized command: " + command);
                    break;
            }
        } catch (Exception e) {
            String formattedCommand = command;
            formattedCommand += arguments.stream().reduce("", (a, b) -> a + " " + b);
            output.println("Exception while running command: " + formattedCommand);
            e.printStackTrace(output);
        }
    }

    private void createGraph(List<String> arguments) {
        if (arguments.size() != 1) {
            throw new CommandException("Bad arguments to CreateGraph: " + arguments);
        }

        String graphName = arguments.get(0);
        createGraph(graphName);
    }

    private void createGraph(String graphName) {
        // TODO Insert your code here.

        // graphs.put(graphName, ___);
        // output.println(...);

        graphs.put(graphName, new Graph<>());
        output.println("created graph " + graphName);   // Remember to use output!!! Research this?
    }

    private void addNode(List<String> arguments) {
        if (arguments.size() != 2) {
            throw new CommandException("Bad arguments to AddNode: " + arguments);
        }

        String graphName = arguments.get(0);
        String nodeName = arguments.get(1);

        addNode(graphName, nodeName);
    }

    private void addNode(String graphName, String nodeName) {
        // TODO Insert your code here.

        // ___ = graphs.get(graphName);
        // output.println(...);

        Graph<String, String> new_graph = graphs.get(graphName);        // initialize graph
        new_graph.addNode(nodeName);                                    // add node
        output.println("added node " + nodeName + " to " + graphName);  // ouput 
    }

    private void addEdge(List<String> arguments) {
        if (arguments.size() != 4) {
            throw new CommandException("Bad arguments to AddEdge: " + arguments);
        }

        String graphName = arguments.get(0);
        String parentName = arguments.get(1);
        String childName = arguments.get(2);
        String edgeLabel = arguments.get(3);

        addEdge(graphName, parentName, childName, edgeLabel);
    }

    private void addEdge(String graphName, String parentName, String childName,
                         String edgeLabel) {
        // TODO Insert your code here.

        // ___ = graphs.get(graphName);
        // output.println(...);

        Graph<String, String> new_graph = graphs.get(graphName);        // initialize graph

        // add nodes 
        new_graph.addNode(parentName);
        new_graph.addNode(childName);

        // add edges 
        new_graph.addEdge(parentName, childName, edgeLabel);

        // output 
        output.println("added edge " + edgeLabel +
                " from " + parentName +
                " to " + childName +
                " in " + graphName);
    }

    private void listNodes(List<String> arguments) {
        if (arguments.size() != 1) {
            throw new CommandException("Bad arguments to ListNodes: " + arguments);
        }

        String graphName = arguments.get(0);
        listNodes(graphName);
    }

    private void listNodes(String graphName) {
        // TODO Insert your code here.

        // ___ = graphs.get(graphName);
        // output.println(...);


        Graph<String, String> new_graph = graphs.get(graphName);                    // Initialize Graph 
        List<String> sorted_listNodes = new ArrayList<>(new_graph.getAllNodes());   // Initliaze List
        
        String listNodes_string = graphName + " contains:";                         // Initialize String                           

        Collections.sort(sorted_listNodes);
        
        // Traverse all nodes in list 
        for (String node : sorted_listNodes)
            listNodes_string += " " + node;

        output.println(listNodes_string);
    }

    private void listChildren(List<String> arguments) {
        if (arguments.size() != 2) {
            throw new CommandException("Bad arguments to ListChildren: " + arguments);
        }

        String graphName = arguments.get(0);
        String parentName = arguments.get(1);
        listChildren(graphName, parentName);
    }

    private void listChildren(String graphName, String parentName) {
        // TODO Insert your code here.

        // ___ = graphs.get(graphName);
        // output.println(...);

        // Initialize objects
        Graph<String, String> new_graph = graphs.get(graphName);
        List<Graph.EdgeLabeled<String, String>> listChildren = new ArrayList<>(new_graph.getEdges(parentName));

        // Initilize string
        String listChildren_string = "the children of " + parentName + " in " + graphName + " are:";


        //  Sort through the list
        listChildren.sort((node1, node2) -> {

            boolean dest_equals  = (node1.getDest().equals(node2.getDest())); //
            boolean labelEdge_equals  = (node1.getEdgeLabel().equals(node2.getEdgeLabel()));

            // Check for dest equals
            if (!dest_equals)
                return (node1.getDest().compareTo(node2.getDest()));
            // Checl for label edge equals
            if (!labelEdge_equals)
                return (node1.getEdgeLabel().compareTo(node2.getEdgeLabel()));

            return 0;
        });

        // Output children into string
        for (Graph.EdgeLabeled<String, String> label_edge : listChildren) {
            listChildren_string += " " + label_edge.getDest() + "(" + label_edge.getEdgeLabel() + ")";
        }
        output.println(listChildren_string);
    }

    /**
     * This exception results when the input file cannot be parsed properly
     **/
    static class CommandException extends RuntimeException {

        public CommandException() {
            super();
        }

        public CommandException(String s) {
            super(s);
        }

        public static final long serialVersionUID = 3495;
    }
}
