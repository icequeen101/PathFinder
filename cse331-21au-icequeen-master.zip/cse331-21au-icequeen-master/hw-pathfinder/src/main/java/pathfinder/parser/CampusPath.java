/*
 * Copyright (C) 2021 Kevin Zatloukal.  All rights reserved.  Permission is
 * hereby granted to students registered for University of Washington
 * CSE 331 for use solely during Spring Quarter 2021 for purposes of
 * the course.  No other use, copying, distribution, or modification
 * is permitted without prior written consent. Copyrights for
 * third-party components of this work must be honored.  Instructors
 * interested in reusing these course materials should contact the
 * author.
 */

package pathfinder.parser;

// Import Graph Files

import graph.UpdatedGraph;
import graph.EdgeLabeled;

// Import Path Finder - Path File
import pathfinder.datastructures.Path;

// Import Other Libraries
import java.util.*;

/**
 * This represents one immutable entry of the data in campus_paths.csv,
 */
public class CampusPath {

    /**
     * The pixel-x coordinate of the first point in this path segment.
     */
    private final double x1;

    /**
     * The pixel-y coordinate of the first point in this path segment.
     */
    private final double y1;

    /**
     * The pixel-x coordinate of the second point in this path segment.
     */
    private final double x2;

    /**
     * The pixel-y coordinate of the second point in this path segment.
     */
    private final double y2;

    /**
     * The distance between the points as described in the dataset.
     */
    private final double distance;

    /**
     * Creates a new immutable CampusPath entry containing the provided data.
     *
     * @param x1       The pixel-x coordinate of the first point
     * @param y1       The pixel-y coordinate of the first point
     * @param x2       The pixel-x coordinate of the second point
     * @param y2       The pixel-y coordinate of the second point
     * @param distance The distance between the points as described in the dataset
     */
    public CampusPath(double x1, double y1, double x2, double y2, double distance) {
        this.x1 = x1;
        this.y1 = y1;
        this.x2 = x2;
        this.y2 = y2;
        this.distance = distance;
    }

    /**
     * @return The pixel-x coordinate of the first point in this path segment.
     */
    public double getX1() {
        return x1;
    }

    /**
     * @return The pixel-y coordinate of the first point in this path segment.
     */
    public double getY1() {
        return y1;
    }

    /**
     * @return The pixel-x coordinate of the second point in this path segment.
     */
    public double getX2() {
        return x2;
    }

    /**
     * @return The pixel-y coordinate of the second point in this path segment.
     */
    public double getY2() {
        return y2;
    }

    /**
     * @return The distance between the points as described in the dataset.
     */
    public double getDistance() {
        return distance;
    }

    @Override
    public String toString() {
        return String.format("[Path (%.3f, %.3f) -> (%.3f, %.3f); Distance: %.3f]",
                x1, y1, x2, y2, distance);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof CampusPath)) {
            return false;
        }
        if (this.hashCode() != other.hashCode()) {
            // Equal objects must have equal hashCodes, according
            // to the hashCode spec, so if their hashCodes aren't equal,
            // the object's can't be equal.
            return false;
        }
        CampusPath that = (CampusPath) other;
        return (Double.compare(this.x1, that.x1) == 0)
                && (Double.compare(this.y1, that.y1) == 0)
                && (Double.compare(this.x2, that.x2) == 0)
                && (Double.compare(this.y2, that.y2) == 0)
                && (Double.compare(this.distance, that.distance) == 0);
    }

    @Override
    public int hashCode() {
        int result = Double.hashCode(this.distance);
        result = (31 * result) + Double.hashCode(this.x1);
        result = (31 * result) + Double.hashCode(this.y1);
        result = (31 * result) + Double.hashCode(this.x2);
        result = (31 * result) + Double.hashCode(this.y2);
        return result;
    }

    // TODO~NOTE: Implement Dijkstra's Algorithm

    /**
     * NAME: DijkstraPath
     * <p>
     * DESCRIPTION: Dijkstra's algorithm, which finds a minimum-cost path between two given nodes in a graph with all
     * nonnegative edge weights. (This restriction is important, Dijkstra's algorithm can fail if there are negative
     * edge weights. In this assignment, since all edge weights represent physical distances, all our edge weights are
     * nonnegative and Dijkstra's algorithm will work well.)
     *
     * @param <A>   - Generics
     * @param graph - Graph-to-be analyzed
     * @param start - Desired starting node to-be-found
     * @param end   - Desired ending node to-be-found
     * @return The minimum-cost path from the start to end node
     * @spec.requires Edge weights must be non-negative (Read above for restriction)
     */


    public static <A> Path<A> DijkstraPath(UpdatedGraph<A, Double> graph, A start, A end) {

        /* Referencing HW7 - Dijkstra's Algorithm Pseudocode

            start = starting node
            dest = destination node
            active = priority queue (Named: activeQueue in code below)

            Each element is a path from start to a given node.
            A path's 'priority' in the queue is the total cost of that path.
            Nodes for which no path is known yet are not in the queue.
         */

        Queue<Path<A>> activeQueue = new PriorityQueue<Path<A>>(15, new Comparator<Path<A>>() {
            @Override

            public int compare(Path<A> object1, Path<A> object2) {
                double w1 = 0;
                double w2 = 0;
                int result = Double.compare(w1, w2);
                if (result == 0) {
                    result = Double.compare(object1.getCost(), object2.getCost());
                }
                return result;
            }
        });

        /* HW 7 - Pseudocode 1

         finished = set of nodes for which we know the minimum-cost path from start.
         (Named: finshedSet)

        */

        Set<A> finshedSet = new HashSet<>();

        /* HW 7 - Pseudocode 2

        Initially we only know of the path from start to itself, which has
        a cost of zero because it contains no edges.
        Add a path from start to itself to active

        */

        Path<A> selfLoop = new Path<>(start);
        activeQueue.add(selfLoop);


       /* HW 7 - Pseudocode 3

        while active is non-empty:

        // minPath is the lowest-cost path in active and,
        // if minDest isn't already 'finished,' is the
        // minimum-cost path to the node minDest

        minPath = active.removeMin()
        minDest = destination node in minPath

       */

        while (!activeQueue.isEmpty()) {

            Path<A> minPath = activeQueue.remove(); // minPath = active.removeMin()
            A minDest = minPath.getEnd();           // minDest = destination node in minPath

            /* HW 7 - Pseudocode 4

            if minDest is dest:
                return minPath

             */

            if (minDest.equals(end))
                return minPath;

            /* HW 7 - Pseudocode 5

            if minDest is in finished:
                continue

             */

            if (finshedSet.contains(minDest))
                continue;

            /* HW 7 - Pseudocode 6

             for each edge e = ⟨minDest, child⟩: // For all children of minDest
             // If we don't know the minimum-cost path from start to child,
             // examine the path we've just found
             if child is not in finished:
               newPath = minPath + e
               add newPath to active

             */


            for (EdgeLabeled<A, Double> edge : graph.getEdges(minDest)) {

                boolean childInFinished = finshedSet.contains(edge.getDest());

                double edgeValue = edge.getLabel().doubleValue();

                if (!childInFinished) {
                    Path<A> newPath = minPath.extend(edge.getDest(), edgeValue);
                    activeQueue.add(newPath);

                }
            }

            finshedSet.add(minDest); // add minDest to finished
        }

        /* HW 7 - Pseudocode 7

        // If the loop terminates, then no path exists from start to dest.
        // The implementation should indicate this to the client.
         */

        return null;
    }
}
