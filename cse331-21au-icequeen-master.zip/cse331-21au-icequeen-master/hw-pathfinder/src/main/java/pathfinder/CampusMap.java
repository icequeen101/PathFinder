/*
 * Copyright (C) 2021 Kevin Zatloukal.  All rights reserved.  Permission is
 * hereby granted to students registered for University of Washington
 * CSE 331 for use solely during Spring Quarter 2021 for purposes of
 * the course.  No other use, copying, distribution, or modification
 * is permitted without prior written consent. Copyrights for
 * third-party components of this work must be honored.  Instructors
 * interested in reusing these course materials should contact the
 * author.
 */

package pathfinder;

// Import Graph Files

import graph.UpdatedGraph;

// Import Parser Files
import pathfinder.parser.CampusBuilding;
import pathfinder.parser.CampusPath;
import pathfinder.parser.CampusPathsParser;

// Import Data-Structure files
import pathfinder.datastructures.Path;
import pathfinder.datastructures.Point;

// Import Other Libraries
import java.util.Collections;
import java.util.Map;
import java.util.List;
import java.util.HashMap;

public class CampusMap implements ModelAPI {

    // Initialize variables
    private UpdatedGraph<Point, Double> graph;
    private Map<String, String> shortName_longName;     // short name to long name
    private Map<String, Point> shortName_point;        // short name to Point

    public CampusMap() {

        // Initialize lists
        List<CampusBuilding> campusBuildings_List = CampusPathsParser.parseCampusBuildings("campus_buildings.csv");
        List<CampusPath> campusPaths_List = CampusPathsParser.parseCampusPaths("campus_paths.csv");

        // Initialize HashMaps
        shortName_longName = new HashMap<>();
        shortName_point = new HashMap<>();

        // TRAVERSE: buildings in the campusBuildings_List
        for (CampusBuilding buildings : campusBuildings_List) {
            // CHECK if buildings is null
            if (buildings != null) {
                // Add the buildings/convert
                shortName_longName.put(buildings.getShortName(), buildings.getLongName());
                shortName_point.put(buildings.getShortName(), new Point(buildings.getX(), buildings.getY()));
            }
        }

        // Update graph
        graph = new UpdatedGraph<>();

        // TRAVERSE: paths in campusPaths_List
        for (CampusPath paths : campusPaths_List) {
            //Initialize points start & end
            Point start = new Point(paths.getX1(), paths.getY1()),
                    end = new Point(paths.getX2(), paths.getY2());

            // Add nodes
            graph.addNode(start);
            graph.addNode(end);

            // Initialize booleans start in if graph contains the starting & ending nodes
            boolean containsStart = graph.containsNode(start),
                    containsEnd = graph.containsNode(end);

            // CHECK: if start & end node exist and then add edge
            if (containsStart && containsEnd) {
                graph.addEdge(start, end, paths.getDistance());
                graph.addEdge(end, start, paths.getDistance());
            }
        }
    }

    @Override
    public boolean shortNameExists(String shortName) {
        // TODO: Implement this method exactly as it is specified in ModelAPI
        // throw new RuntimeException("Not Implemented Yet");
        return buildingNames().containsKey(shortName);
    }

    @Override
    public String longNameForShort(String shortName) {
        // TODO: Implement this method exactly as it is specified in ModelAPI
        // throw new RuntimeException("Not Implemented Yet");
        return buildingNames().get(shortName);
    }

    @Override
    public Map<String, String> buildingNames() {
        // TODO: Implement this method exactly as it is specified in ModelAPI
        // throw new RuntimeException("Not Implemented Yet");
        return Collections.unmodifiableMap(shortName_longName);

    }

    @Override
    public Path<Point> findShortestPath(String startShortName, String endShortName) {
        // TODO: Implement this method exactly as it is specified in ModelAPI
        // throw new RuntimeException("Not Implemented Yet");

        // Initialize variables - BOOLEAN
        boolean nullShortName = (startShortName == null) || (endShortName == null),
                containsStart = buildingNames().containsKey(startShortName),
                containsEnd = buildingNames().containsKey(endShortName);

        if (nullShortName || !containsStart || !containsEnd)
            throw new IllegalArgumentException();

        return null;
    }

}
