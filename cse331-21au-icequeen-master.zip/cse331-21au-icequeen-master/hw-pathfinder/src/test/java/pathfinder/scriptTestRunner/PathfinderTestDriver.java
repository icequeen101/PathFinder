/*
 * Copyright (C) 2021 Kevin Zatloukal.  All rights reserved.  Permission is
 * hereby granted to students registered for University of Washington
 * CSE 331 for use solely during Spring Quarter 2021 for purposes of
 * the course.  No other use, copying, distribution, or modification
 * is permitted without prior written consent. Copyrights for
 * third-party components of this work must be honored.  Instructors
 * interested in reusing these course materials should contact the
 * author.
 */

package pathfinder.scriptTestRunner;

// Import UpdatedGraph Files
import graph.UpdatedGraph;
import graph.EdgeLabeled;

// Import Marvel - MarvelPath Files
import marvel.MarvelPaths;

// Import PathFinder Files
import pathfinder.datastructures.Path;
import pathfinder.datastructures.Point;
import pathfinder.parser.CampusPath;

// Import Other Libraries
import java.io.*;
import java.util.*;

/**
 * This class implements a test driver that uses a script file format
 * to test an implementation of Dijkstra's algorithm on a graph.
 *
 * NOTE: HEAVILY REFERENCE GraphTestDriver.jaca & MarvelTestDriver.java
 */
public class PathfinderTestDriver {

    // ***************************
    // ***  JUnit Test Driver  ***
    // ***************************


    // Initialize Macro-values
    public static final int GRAPH_NULL = 0;

    // Initialize Objects
    private final Map<String, UpdatedGraph<String, Double>> graphs = new HashMap<>();

    private final BufferedReader input;
    private final PrintWriter output;


    // Leave this constructor public
    public PathfinderTestDriver(Reader r, Writer w) {
        // TODO: Implement this, reading commands from `r` and writing output to `w`.
        // See GraphTestDriver as an example.

        input = new BufferedReader(r);
        output = new PrintWriter(w);
    }

    // Leave this method public
    public void runTests()
            throws IOException {
        // TODO: Implement this.

        String inputLine;

        while ((inputLine = input.readLine()) != null) {
            if ((inputLine.trim().length() == 0) || (inputLine.charAt(0) == '#'))

                // echo blank and comment lines
                output.println(inputLine);

            else {

                // separate the input line on white space
                StringTokenizer st = new StringTokenizer(inputLine);

                if (st.hasMoreTokens()) {
                    String command = st.nextToken();

                    List<String> arguments = new ArrayList<>();

                    while (st.hasMoreTokens())
                        arguments.add(st.nextToken());


                    executeCommand(command, arguments);
                }
            }
            output.flush();
        }
    }

    private void executeCommand(String command, List<String> arguments) {
        try {
            switch (command) {
                case "CreateGraph":
                    createGraph(arguments);
                    break;
                case "AddNode":
                    addNode(arguments);
                    break;
                case "AddEdge":
                    addEdge(arguments);
                    break;
                case "ListNodes":
                    listNodes(arguments);
                    break;
                case "ListChildren":
                    listChildren(arguments);
                    break;
                case "FindPath":
                    findPath(arguments);
                    break;
                default:
                    output.println("Unrecognized command: " + command);
                    break;
            }
        } catch (Exception e) {
            String formattedCommand = command;
            formattedCommand += arguments.stream().reduce("", (a, b) -> a + " " + b);
            output.println("Exception while running command: " + formattedCommand);
            e.printStackTrace(output);
        }
    }

    private void createGraph(List<String> arguments) {
        if (arguments.size() != 1)
            throw new CommandException("Bad arguments to CreateGraph: " + arguments);


        String graphName = arguments.get(0);
        createGraph(graphName);
    }

    private void createGraph(String graphName) {
        // TODO Insert your code here.

        // graphs.put(graphName, ___);
        // output.println(...);
        UpdatedGraph<String,Double> new_graph = new UpdatedGraph<String, Double>();
        graphs.put(graphName, new_graph);
        output.println("created graph " + graphName);
    }

    private void addNode(List<String> arguments) {
        if (arguments.size() != 2)
            throw new CommandException("Bad arguments to AddNode: " + arguments);


        String graphName = arguments.get(0);
        String nodeName = arguments.get(1);

        addNode(graphName, nodeName);
    }

    private void addNode(String graphName, String nodeName) {
        // TODO MISS Insert your code here.

        // ___ = graphs.get(graphName);
        // output.println(...);

        UpdatedGraph<String, Double> new_graph = graphs.get(graphName);     // initialize graph
        new_graph.addNode(nodeName);                                        // add node
        output.println("added node " + nodeName + " to " + graphName);      // output
    }

    private void addEdge(List<String> arguments) {
        if (arguments.size() != 4)
            throw new CommandException("Bad arguments to AddEdge: " + arguments);


        String graphName = arguments.get(0);
        String parentName = arguments.get(1);
        String childName = arguments.get(2);
        String edgeWeight = arguments.get(3);
        double edgeLabel = Double.parseDouble(edgeWeight);

        addEdge(graphName, parentName, childName, edgeLabel);
    }

    private void addEdge(String graphName, String parentName, String childName,
                         double edgeLabel) {
        // TODO Insert your code here.

        // ___ = graphs.get(graphName);
        // output.println(...);

        UpdatedGraph<String, Double> new_graph = graphs.get(graphName);        // initialize graph - changed 2nd parameter from String to Double

        // add nodes
        //new_graph.addNode(parentName);
        //new_graph.addNode(childName);

        // add edges
        new_graph.addEdge(parentName, childName, edgeLabel);

        // output
        output.println("added edge " + String.format("%.3f",edgeLabel) +
                " from " + parentName +
                " to " + childName +
                " in " + graphName);
    }

    private void listNodes(List<String> arguments) {
        if (arguments.size() != 1)
            throw new CommandException("Bad arguments to ListNodes: " + arguments);


        String graphName = arguments.get(0);
        listNodes(graphName);
    }

    private void listNodes(String graphName) {
        // TODO Insert your code here.

        // ___ = graphs.get(graphName);
        // output.println(...);


        UpdatedGraph<String, Double> new_graph = graphs.get(graphName);             // Initialize Graph - changed 2nd parameter from String to Double
        List<String> sorted_listNodes = new ArrayList<>(new_graph.getAllNodes());   // Initialize List

        String listNodes_string = graphName + " contains:";                         // Initialize String

        Collections.sort(sorted_listNodes);                                         // Use collections - Java dict

        // Traverse all nodes in list
        for (String node : sorted_listNodes)
            listNodes_string += " " + node;

        output.println(listNodes_string);
    }

    private void listChildren(List<String> arguments) {
        if (arguments.size() != 2)
            throw new CommandException("Bad arguments to ListChildren: " + arguments);


        String graphName = arguments.get(0);
        String parentName = arguments.get(1);
        listChildren(graphName, parentName);
    }

    private void listChildren(String graphName, String parentName) {
        // TODO Insert your code here. - MODIFIED

        // Create new graph - changed 2nd parameter from String to Double
        UpdatedGraph<String, Double> new_graph = graphs.get(graphName);

        // Get sorted list - changed 2nd parameter from String to Double
        List<EdgeLabeled<String, Double>> sort_list = new ArrayList<>(); // Edge inside

        // Add all in new Graph
        sort_list.addAll(new_graph.getEdges(parentName));

        // Collections
        Collections.sort(sort_list, Comparator.comparing(edge -> edge.getDest() + edge.getLabel()));

        // String
        String string_result = "the children of " + parentName + " in " + graphName + " are:";

        // Traverse sort list for edges - changed 2nd parameter from String to Double
        for (EdgeLabeled<String, Double> edge : sort_list)
            string_result += " " + edge.getDest() + "(" + String.format("%.3f",edge.getLabel()) + ")";

        output.println(string_result);

    }

    private void findPath(List<String> arguments) {

        // TODO: How to do code here? COL

        if (arguments.size() != 3)
            throw new CommandException("Bad arguments to findPath: " + arguments);

        // Update graphName, startNode, and endNode
        String graphName = arguments.get(0),
                startNode = arguments.get(1),
                endNode = arguments.get(2);

        // Call function
        findPath(graphName, startNode, endNode);
    }

    private void findPath(String graphName, String startNode, String endNode) {

        // TODO: How to do code here? COL

        // Cet new graph - changed 2nd parameter from String to Double
        UpdatedGraph<String, Double> new_graph = graphs.get(graphName);

        // Check for unknown cases
        if (!(new_graph.containsNode(startNode)) && !(new_graph.containsNode(endNode))) {   // no start node and end node
            output.println("unknown: " + startNode);                                        // (1)
            output.println("unknown: " + endNode);                                          // (2)

        } else if (!(new_graph.containsNode(startNode)))                                    // no start node
            output.println("unknown: " + startNode);                                        // (1)

        else if (!(new_graph.containsNode(endNode)))                                        // no end node
            output.println("unknown: " + endNode);                                          // (2)

            // Otherwise, get path from start node to end node
        else {

            // Create strings
            String tmp = startNode,
                    string_result = "path from " + startNode + " to " + endNode + ":";

            // Create Path for the CampusPath - Dijkstra Path
            // Changed 2nd parameter from String to Double
            Path<String> path = CampusPath.DijkstraPath(new_graph, startNode,endNode);

            // Check for cases
            if (startNode.equals(endNode))                  // self-loop
                string_result += "";

            else if (path == null)                     // null
                string_result += "\n" + "no path found";

                // Get path
            else {
                // Traverse through pathList for all the edges
                // Changed 2nd parameter from String to Double

                String string_edgeCost;
                double cost = 0.0;

                for (Path<String>.Segment edge : path) {

                    // Update Edge Cost & Format
                    string_edgeCost = String.format("%.3f",(edge.getCost()));

                    // Update string
                    string_result += "\n" + tmp + " to " + edge.getEnd() + " with weight " + string_edgeCost;

                    // Update cost
                    cost += edge.getCost();

                    tmp = edge.getEnd();    // Need this?
                }
                string_result += "\n" + "total cost: " + String.format("%.3f", cost);
            }
            // String output
            output.println(string_result);
        }
    }

    /**
     * This exception results when the input file cannot be parsed properly
     **/
    static class CommandException extends RuntimeException {

        public CommandException() {
            super();
        }

        public CommandException(String s) {
            super(s);
        }

        public static final long serialVersionUID = 3495;
    }
}
