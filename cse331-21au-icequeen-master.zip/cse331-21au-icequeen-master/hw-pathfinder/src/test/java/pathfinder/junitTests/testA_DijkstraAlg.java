package pathfinder.junitTests;

import graph.UpdatedGraph;
import org.junit.Test;
import pathfinder.parser.CampusPath;

public class testA_DijkstraAlg {

    @Test(expected = AssertionError.class)
    public void test1_InvalidEdge() {
        UpdatedGraph<String, Double> graph = new UpdatedGraph<>();
        graph.addNode("A");
        graph.addNode("B");
        graph.addEdge("A", "B", -100.0);
        CampusPath.DijkstraPath(graph, "A", "B");
    }

    @Test(expected = AssertionError.class)
    public void test2_NullNode() {
        UpdatedGraph<String, Double> graph = new UpdatedGraph<>();
        graph.addNode("A");
        graph.addNode("B");
        graph.addEdge("A", "B", 100.0);
        CampusPath.DijkstraPath(graph, null, "B");
    }

}
