/*
 * Copyright (C) 2021 Kevin Zatloukal.  All rights reserved.  Permission is
 * hereby granted to students registered for University of Washington
 * CSE 331 for use solely during Spring Quarter 2021 for purposes of
 * the course.  No other use, copying, distribution, or modification
 * is permitted without prior written consent. Copyrights for
 * third-party components of this work must be honored.  Instructors
 * interested in reusing these course materials should contact the
 * author.
 */

package campuspaths;

import campuspaths.utils.CORSFilter;

// Files From Pathfinder
import pathfinder.CampusMap;
import pathfinder.datastructures.Path;
import pathfinder.datastructures.Point;

// Data Structure Libraries
import java.util.Collection;
import java.util.Map;

// Additional Libraries
import graph.UpdatedGraph;
import com.google.gson.Gson;
import spark.Spark;



public class SparkServer {

    public static void main(String[] args) {
        CORSFilter corsFilter = new CORSFilter();
        corsFilter.apply();
        // The above two lines help set up some settings that allow the
        // React application to make requests to the Spark server, even though it
        // comes from a different server.
        // You should leave these two lines at the very beginning of main().

        /*
            MODIFIED: Create all the Spark Java routes you need here.

            1. Get the building names (long or short or both)? - EDIT: Let's do short/abbreviated.
            2. Obviously, need the pathfinder option - EDIT: It's not working now?!?!

         */

        // Stores the current campus graph for "/findPath"
        CampusMap campusGraph = new CampusMap();

        // Start GSON
        Gson gson = new Gson();

        /* Get the list for names of all the campus buildings - Abbreviated */
        Spark.get("/getBuildingNames", (request, response) -> {
            Map<String, String> campusBuildings = campusGraph.buildingNames();      // Hashmap retrieve building names
            Collection<String> campusBuildingNames = campusBuildings.keySet();      // Use collections? keyset()
            return (gson.toJson(campusBuildingNames));
        });

        /* Getting a starting building and destination building, get the shortest path between them */
        Spark.get("/findPath", (request, response) -> {

            // Extension keywords
            String start = request.queryParams("start"),
                    end = request.queryParams("end");

            // Check Cases
            if (start == null || end == null)
                Spark.halt(400, "Must have start and end");

            //if (!campusGraph.buildingNames().containsKey(start)
            //        || !campusGraph.buildingNames().containsKey(end))
            //    Spark.halt(400, "Invalid start and end");

            // Call shortest path
            Path<Point> shortestPath = campusGraph.findShortestPath(start, end);  // WARNING: Check findShortestPath function!!!
            return (gson.toJson(shortestPath));
        });

    }

}
